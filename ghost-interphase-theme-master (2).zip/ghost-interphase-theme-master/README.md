# ghost-interphase-theme
A ghost theme based off of [template.co/interphase](http://templated.co/interphase).

### Installation instructions

Simply download this repository and place the content in your `/content/themes/` folder of your ghost project (in a separate folder).

### Desktop

![interphase-desktop](https://cloud.githubusercontent.com/assets/777823/7796254/af798436-02dd-11e5-890d-de51253d26a3.png)

### Mobile

![interphase](https://cloud.githubusercontent.com/assets/777823/7796251/a914b20a-02dd-11e5-8db9-04a29d42a134.png)
